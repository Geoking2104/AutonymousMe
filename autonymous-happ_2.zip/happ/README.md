# Autonymous.me — hApp

Holochain hApp implementing a self-sovereign identity wallet with OpenID4VP + SD-JWT support.

## Quick start

```bash
make setup    # install Rust wasm32 target + holochain CLI + node deps
make build    # compile zomes → pack DNA → pack hApp → build UI
make test     # run unit tests (8 tests, 0 failures)
make run-conductor  # start Holochain conductor on ws://localhost:8888
```

## Structure

| Path | Description |
|------|-------------|
| `dnas/autonymous/zomes/identity_wallet/` | DID + VC wallet + audit log zome (Rust) |
| `dnas/autonymous/zomes/openid4vp/` | OpenID4VP flow + VP Token builder (Rust) |
| `ui/src/client.ts` | Typed TypeScript wrappers for all zome calls |
| `ui/src/main.ts` | UI boot + Holochain conductor hydration |
| `docs/architecture.md` | Full technical spec, SD-JWT format, eIDAS mapping |

## Status

- ✅ identity_wallet zome compiles (HDK 0.4.4 / wasm32)
- ✅ openid4vp zome compiles (HDK 0.4.4 / wasm32)
- ✅ 8 unit tests pass
- 🔄 DNA pack + integration tests (requires holochain binary)
- 📋 Browser extension + mobile app (Phase 5)
