# Contributing to Autonymous.me

Thank you for contributing. This is a community protocol — your contributions directly shape the standard.

## Before you start

- Read the [README](README.md) to understand the architecture
- Check [open issues](https://github.com/geoking2104/autonymous.me/issues) before opening a new one
- For significant changes, open an issue first to discuss the approach

## Setup

```bash
# Prerequisites: Rust 1.77+, Node 20+
make setup      # installs wasm target + holochain CLI + node deps
make build      # compile zomes + pack DNA/hApp + build UI
make test       # run all tests
```

## Project structure

```
Cargo.toml                          Rust workspace
dnas/autonymous/
  dna.yaml                          DNA manifest
  zomes/
    identity_wallet/src/lib.rs      DID management, VC wallet, audit log
    openid4vp/src/lib.rs            OpenID4VP flow, VP Token builder
ui/src/
  client.ts                         Typed Holochain zome wrappers
  main.ts                           UI boot + hydration
```

## Making changes

### Zome code (Rust)

1. Edit files in `dnas/autonymous/zomes/`
2. `cargo check --workspace` — fast error checking
3. `cargo test --workspace` — run unit tests
4. `cargo build --release --target wasm32-unknown-unknown` — full wasm build

Key rules:
- All entries must be `#[hdk_entry_helper]`
- All public zome functions must be `#[hdk_extern]`
- Private entries (credentials, DIDs) must use `visibility = "private"`
- Every sensitive action must write an `AuditEntry` to the Source Chain
- Validation functions must be pure — no side effects

### UI code (TypeScript)

1. Edit files in `ui/src/`
2. `cd ui && npm run dev` — Vite dev server with HMR
3. All zome calls go through `client.ts` — do not call `ws.callZome()` directly

### Adding a new zome function

1. Define input/output structs with `#[derive(Serialize, Deserialize, Debug)]`
2. Write the function with `#[hdk_extern]`
3. Add validation in `validate()`
4. Add a typed wrapper in `ui/src/client.ts`
5. Write at least one unit test

## Pull request checklist

- [ ] `cargo test --workspace` passes
- [ ] `cargo clippy --workspace` shows no warnings
- [ ] New zome functions have a typed wrapper in `client.ts`
- [ ] Sensitive actions are logged to the Source Chain via `log_audit()`
- [ ] No credentials or personal data are stored in public entries
- [ ] PR description explains the change and links the issue

## Commit style

```
type(scope): short description

feat(openid4vp): add redirect_uri support for response_mode=redirect
fix(identity_wallet): handle empty available_claims gracefully
docs(readme): add sequence diagram for issuance flow
test(openid4vp): add replay attack detection test
```

Types: `feat` `fix` `docs` `test` `refactor` `chore`

## Standards references

Always reference the spec when implementing protocol behaviour:

- OpenID4VP: https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
- SD-JWT RFC 9901: https://www.rfc-editor.org/rfc/rfc9901.html
- W3C DID 1.0: https://www.w3.org/TR/did-core/
- W3C VC 2.0: https://www.w3.org/TR/vc-data-model-2.0/
- eIDAS 2.0: https://eur-lex.europa.eu/eli/reg/2024/1183/oj

## Non-developer contributions

Not writing Rust? Still hugely valuable:

- **Testing**: open `index.html` and run the OpenID4VP demo. File issues for anything confusing.
- **Documentation**: improve explanations in `docs/`, fix typos, add examples
- **Legal/compliance**: eIDAS 2.0 compliance needs lawyers. Open issues with regulatory questions.
- **Translations**: create `docs/i18n/<lang>/` with translated content

## Code of conduct

Be direct. Be constructive. Disagree on ideas, not on people.
This project follows the [Contributor Covenant](https://www.contributor-covenant.org/) v2.1.

## Contact

support@autonymous.me
